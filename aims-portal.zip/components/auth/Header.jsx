import React from "react";

const Header = () =>{
    return(
        <header style={{textAlign:'center' , padding:'3rem' , fontSize:'2rem' , fontWeight:'bold'}}> 
            Welcome to AIMS PORTAL
        </header>
    );
};

export default Header;