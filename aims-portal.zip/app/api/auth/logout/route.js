import cookie from 'cookie';

export default function handler(req, res) {
    res.setHeader('Set-Cookie', cookie.serialize('authToken', null, {
        httpOnly: true,
        expires: new Date(0),
        path: '/',
        sameSite: 'Strict', // Prevents CSRF issues
    }));

    res.status(200).json({ message: 'Logged out' });
}
