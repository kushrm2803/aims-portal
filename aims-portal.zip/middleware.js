import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function middleware(req) {
  const cookieStore = cookies();
  const token = await cookieStore.get("authToken");
  const pathname = req.nextUrl.pathname;

  const protectedRoutes = [
    "/home",
    "/profile",
    "/about",
    "/courses",
    "/help",
    "/student-record",
    "/current-semester",
  ];

  // If the path is in protected routes and no token, redirect to login
  if (protectedRoutes.includes(pathname) && !token) {
    return NextResponse.redirect(new URL("/login", req.url));
  }

  return NextResponse.next();
}
